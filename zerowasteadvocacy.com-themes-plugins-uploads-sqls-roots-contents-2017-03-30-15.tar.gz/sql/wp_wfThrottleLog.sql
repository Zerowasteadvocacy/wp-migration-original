SET NAMES 'utf8';
DROP TABLE IF EXISTS `wp_wfThrottleLog`;
CREATE TABLE `wp_wfThrottleLog` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `startTime` int(10) unsigned NOT NULL,
  `endTime` int(10) unsigned NOT NULL,
  `timesThrottled` int(10) unsigned NOT NULL,
  `lastReason` varchar(255) NOT NULL,
  PRIMARY KEY (`IP`),
  KEY `k2` (`endTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `wp_wfThrottleLog` (`IP`, `startTime`, `endTime`, `timesThrottled`, `lastReason`) VALUES ('\0\0\0\0\0\0\0\0\0\0��.ir�',1441966791,1442000879,12681,'Exceeded the maximum number of page requests per minute for humans.');
INSERT INTO `wp_wfThrottleLog` (`IP`, `startTime`, `endTime`, `timesThrottled`, `lastReason`) VALUES ('\0\0\0\0\0\0\0\0\0\0��2a��',1458739968,1458740039,16,'Exceeded the maximum number of page not found errors per minute for humans.');
INSERT INTO `wp_wfThrottleLog` (`IP`, `startTime`, `endTime`, `timesThrottled`, `lastReason`) VALUES ('\0\0\0\0\0\0\0\0\0\0��6�1F',1439286097,1439286180,118,'Exceeded the maximum number of page not found errors per minute for humans.');
INSERT INTO `wp_wfThrottleLog` (`IP`, `startTime`, `endTime`, `timesThrottled`, `lastReason`) VALUES ('\0\0\0\0\0\0\0\0\0\0��@OKR',1441058272,1441058333,17,'Exceeded the maximum number of page requests per minute for humans.');
INSERT INTO `wp_wfThrottleLog` (`IP`, `startTime`, `endTime`, `timesThrottled`, `lastReason`) VALUES ('\0\0\0\0\0\0\0\0\0\0��J���',1438683877,1438683879,5,'Exceeded the maximum number of page requests per minute for humans.');
INSERT INTO `wp_wfThrottleLog` (`IP`, `startTime`, `endTime`, `timesThrottled`, `lastReason`) VALUES ('\0\0\0\0\0\0\0\0\0\0��R��',1445520700,1445520770,48,'Exceeded the maximum number of page not found errors per minute for humans.');
INSERT INTO `wp_wfThrottleLog` (`IP`, `startTime`, `endTime`, `timesThrottled`, `lastReason`) VALUES ('\0\0\0\0\0\0\0\0\0\0��X�\Z.',1441914296,1441914299,4,'Exceeded the maximum number of page requests per minute for humans.');
INSERT INTO `wp_wfThrottleLog` (`IP`, `startTime`, `endTime`, `timesThrottled`, `lastReason`) VALUES ('\0\0\0\0\0\0\0\0\0\0��[y��',1431173080,1431173099,34,'Exceeded the maximum number of page not found errors per minute for humans.');
INSERT INTO `wp_wfThrottleLog` (`IP`, `startTime`, `endTime`, `timesThrottled`, `lastReason`) VALUES ('\0\0\0\0\0\0\0\0\0\0�����',1438739912,1438739939,44,'Exceeded the maximum number of page not found errors per minute for humans.');
INSERT INTO `wp_wfThrottleLog` (`IP`, `startTime`, `endTime`, `timesThrottled`, `lastReason`) VALUES ('\0\0\0\0\0\0\0\0\0\0�����',1438074283,1438074291,15,'Exceeded the maximum number of page not found errors per minute for humans.');
INSERT INTO `wp_wfThrottleLog` (`IP`, `startTime`, `endTime`, `timesThrottled`, `lastReason`) VALUES ('\0\0\0\0\0\0\0\0\0\0��ʂ �',1431256365,1431256370,7,'Exceeded the maximum number of page not found errors per minute for humans.');
INSERT INTO `wp_wfThrottleLog` (`IP`, `startTime`, `endTime`, `timesThrottled`, `lastReason`) VALUES ('\0\0\0\0\0\0\0\0\0\0���mV<',1430579929,1430579939,19,'Exceeded the maximum number of page not found errors per minute for humans.');
