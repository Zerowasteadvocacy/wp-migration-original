SET NAMES 'utf8';
DROP TABLE IF EXISTS `wp_wfNotifications`;
CREATE TABLE `wp_wfNotifications` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `new` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `category` varchar(255) NOT NULL,
  `priority` int(11) NOT NULL DEFAULT '1000',
  `ctime` int(10) unsigned NOT NULL,
  `html` text NOT NULL,
  `links` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `wp_wfNotifications` (`id`, `new`, `category`, `priority`, `ctime`, `html`, `links`) VALUES ('site-AEAAAAA',1,'wfplugin_updates',1000,1490749416,'<a href=\"http://zerowasteadvocacy.com/wp-admin/update-core.php\">Updates are available for 1 plugin and 5 themes</a>','[]');
INSERT INTO `wp_wfNotifications` (`id`, `new`, `category`, `priority`, `ctime`, `html`, `links`) VALUES ('site-AIAAAAA',1,'wfplugin_scan',500,1490753059,'<a href=\"http://zerowasteadvocacy.com/wp-admin/admin.php?page=WordfenceScan\">9 issues found in most recent scan</a>','[]');
