SET NAMES 'utf8';
DROP TABLE IF EXISTS `wp_pmlc_rules`;
CREATE TABLE `wp_pmlc_rules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_id` bigint(20) unsigned NOT NULL,
  `type` enum('ONE_SET','BY_COUNTRY','BY_RULE','EXPIRED','REFERER_MASK') NOT NULL DEFAULT 'ONE_SET',
  `rule` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `link_id` (`link_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

