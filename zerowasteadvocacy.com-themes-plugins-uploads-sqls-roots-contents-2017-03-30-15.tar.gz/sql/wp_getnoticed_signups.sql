SET NAMES 'utf8';
DROP TABLE IF EXISTS `wp_getnoticed_signups`;
CREATE TABLE `wp_getnoticed_signups` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `for` varchar(24) NOT NULL,
  `fname` tinytext NOT NULL,
  `lname` tinytext NOT NULL,
  `email` tinytext NOT NULL,
  `when` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`for`,`email`(64))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

