SET NAMES 'utf8';
DROP TABLE IF EXISTS `wp_pmlc_links`;
CREATE TABLE `wp_pmlc_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `preset` varchar(200) NOT NULL DEFAULT '',
  `redirect_type` enum('301','302','307','REFERER_MASK','META_REFRESH','FRAME','JAVASCRIPT') NOT NULL DEFAULT '301',
  `destination_type` enum('ONE_SET','BY_COUNTRY','BY_RULE') NOT NULL DEFAULT 'ONE_SET',
  `expire_on` date NOT NULL DEFAULT '0000-00-00',
  `forward_url_params` tinyint(1) NOT NULL DEFAULT '1',
  `no_global_tracking_code` tinyint(1) NOT NULL DEFAULT '0',
  `header_tracking_code` text,
  `footer_tracking_code` text,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `is_trashed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

