SET NAMES 'utf8';
DROP TABLE IF EXISTS `wp_pmlc_keywords`;
CREATE TABLE `wp_pmlc_keywords` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `replace_limit` int(10) unsigned NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL DEFAULT '',
  `match_case` tinyint(1) NOT NULL DEFAULT '0',
  `post_id_param` varchar(100) NOT NULL DEFAULT '',
  `rel_nofollow` tinyint(1) NOT NULL DEFAULT '0',
  `target_blank` tinyint(1) NOT NULL DEFAULT '0',
  `is_trashed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `keywords` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

