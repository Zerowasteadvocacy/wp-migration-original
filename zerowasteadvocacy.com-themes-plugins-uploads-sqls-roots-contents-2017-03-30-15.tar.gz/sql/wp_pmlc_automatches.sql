SET NAMES 'utf8';
DROP TABLE IF EXISTS `wp_pmlc_automatches`;
CREATE TABLE `wp_pmlc_automatches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_id` bigint(20) unsigned NOT NULL,
  `url` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `link_id` (`link_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

