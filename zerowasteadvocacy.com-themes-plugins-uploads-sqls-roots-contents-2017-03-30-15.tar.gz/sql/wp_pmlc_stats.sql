SET NAMES 'utf8';
DROP TABLE IF EXISTS `wp_pmlc_stats`;
CREATE TABLE `wp_pmlc_stats` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_id` bigint(20) unsigned NOT NULL,
  `sub_id` varchar(32) NOT NULL DEFAULT '',
  `registered_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rule_type` enum('ONE_SET','BY_COUNTRY','BY_RULE','EXPIRED','REFERER_MASK') NOT NULL DEFAULT 'ONE_SET',
  `destination_url` varchar(255) NOT NULL DEFAULT '',
  `ip` varchar(15) NOT NULL DEFAULT '0.0.0.0',
  `ip_num` int(10) unsigned NOT NULL DEFAULT '0',
  `country` char(2) NOT NULL DEFAULT '',
  `host` varchar(200) NOT NULL DEFAULT '',
  `user_agent` text,
  `accept_language` varchar(50) NOT NULL DEFAULT '',
  `referer` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `registered_on` (`registered_on`),
  KEY `ip_num` (`ip_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

