SET NAMES 'utf8';
DROP TABLE IF EXISTS `wp_wfScanners`;
CREATE TABLE `wp_wfScanners` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24843739,'\0\0\0\0\0\0\0\0\0\0����4�',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24843740,'\0\0\0\0\0\0\0\0\0\0����l�',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24843755,'\0\0\0\0\0\0\0\0\0\0���P�x',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24844135,'\0\0\0\0\0\0\0\0\0\0����U�',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24844217,'\0\0\0\0\0\0\0\0\0\0��?���',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24844578,'\0\0\0\0\0\0\0\0\0\0��[�<',2);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24845180,'\0\0\0\0\0\0\0\0\0\0���P�',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24845317,'\0\0\0\0\0\0\0\0\0\0������',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24845455,'\0\0\0\0\0\0\0\0\0\0����u\n',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24845658,'\0\0\0\0\0\0\0\0\0\0������',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24845689,'\0\0\0\0\0\0\0\0\0\0����U�',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24845866,'\0\0\0\0\0\0\0\0\0\0���7\'I',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24846008,'\0\0\0\0\0\0\0\0\0\0������',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24846231,'\0\0\0\0\0\0\0\0\0\0��?���',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24846280,'\0\0\0\0\0\0\0\0\0\0������',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24846511,'\0\0\0\0\0\0\0\0\0\0��4GMd',2);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24846540,'\0\0\0\0\0\0\0\0\0\0������',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24846615,'\0\0\0\0\0\0\0\0\0\0����\n',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24846732,'\0\0\0\0\0\0\0\0\0\0���P�}',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24846819,'\0\0\0\0\0\0\0\0\0\0������',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24846971,'\0\0\0\0\0\0\0\0\0\0�����',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24846973,'\0\0\0\0\0\0\0\0\0\0��[�<',1);
INSERT INTO `wp_wfScanners` (`eMin`, `IP`, `hits`) VALUES (24846974,'\0\0\0\0\0\0\0\0\0\0��[�<',1);
