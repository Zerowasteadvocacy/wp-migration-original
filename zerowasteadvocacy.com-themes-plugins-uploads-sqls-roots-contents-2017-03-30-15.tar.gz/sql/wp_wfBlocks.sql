SET NAMES 'utf8';
DROP TABLE IF EXISTS `wp_wfBlocks`;
CREATE TABLE `wp_wfBlocks` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `blockedTime` bigint(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `lastAttempt` int(10) unsigned DEFAULT '0',
  `blockedHits` int(10) unsigned DEFAULT '0',
  `wfsn` tinyint(3) unsigned DEFAULT '0',
  `permanent` tinyint(3) unsigned DEFAULT '0',
  PRIMARY KEY (`IP`),
  KEY `k1` (`wfsn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0���',1490782900,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��\'(��',1490776470,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��\'9+',1490813691,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��1��p',1490748290,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��L�:',1490817402,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��PFn',1490778257,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��TW��',1490758642,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��X�q',1490765319,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��Y�x�',1490793563,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��ZJ��',1490812703,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��\\57\'',1490756095,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��\\c',1490773431,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��]��e',1490773648,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��^0�\n',1490764163,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��_�e',1490777654,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��b�͘',1490797116,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��l34�',1490818843,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��m�fU',1490810740,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��yKŨ',1490754201,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0��|�S',1490811180,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0���p^',1490773564,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0���8LQ',1490787723,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0���BF',1490816646,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0���1_',1490759856,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0���\\��',1490749176,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0���{�',1490805448,'Blocked by Wordfence Security Network',0,0,1,0);
INSERT INTO `wp_wfBlocks` (`IP`, `blockedTime`, `reason`, `lastAttempt`, `blockedHits`, `wfsn`, `permanent`) VALUES ('\0\0\0\0\0\0\0\0\0\0���I��',1490788703,'Blocked by Wordfence Security Network',0,0,1,0);
