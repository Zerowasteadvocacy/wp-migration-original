SET NAMES 'utf8';
DROP TABLE IF EXISTS `wp_pmlc_destinations`;
CREATE TABLE `wp_pmlc_destinations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rule_id` bigint(20) unsigned NOT NULL,
  `url` varchar(255) NOT NULL DEFAULT '',
  `weight` float unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rule_id` (`rule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

